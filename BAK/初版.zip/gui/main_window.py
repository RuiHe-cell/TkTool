#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主窗口类
功能：提供数据生成器的图形化界面
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import sys
from typing import List, Dict, Any

# 添加父目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from gui.variable_row import VariableRow
from core.data_generator_core import DataGeneratorCore
from core.file_manager_core import FileManagerCore
from core.config_manager import ConfigManager
from templates.template_manager import TemplateManager

class MainWindow:
    """主窗口类"""
    
    def __init__(self, root):
        self.root = root
        self.variable_rows = []
        
        # 初始化核心组件
        self.data_generator = DataGeneratorCore()
        self.file_manager = FileManagerCore()
        self.template_manager = TemplateManager()
        self.config_manager = ConfigManager()
        
        # 加载用户配置
        self.user_config = self.config_manager.load_config()
        
        self.setup_window()
        self.create_widgets()
        self.add_initial_variable_row()
        
        # 应用保存的配置
        self.apply_saved_config()
    
    def setup_window(self):
        """设置窗口属性"""
        self.root.title("数据生成器 v2.0")
        self.root.geometry("900x700")
        self.root.resizable(True, True)
        
        # 绑定窗口关闭事件
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # 设置窗口图标（如果有的话）
        try:
            # self.root.iconbitmap('icon.ico')
            pass
        except:
            pass
    
    def create_widgets(self):
        """创建界面组件"""
        # 主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 配置网格权重
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # 标题
        title_label = ttk.Label(main_frame, text="数据生成器配置", font=('Arial', 14, 'bold'))
        title_label.grid(row=0, column=0, pady=(0, 10), sticky=tk.W)
        
        # 变量配置区域（可滚动）
        self.create_variable_area(main_frame)
        
        # 控制按钮区域
        self.create_control_area(main_frame)
        
        # 生成配置区域
        self.create_generation_area(main_frame)
    
    def create_variable_area(self, parent):
        """创建变量配置区域"""
        # 变量配置框架
        var_frame = ttk.LabelFrame(parent, text="变量配置", padding="5")
        var_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        var_frame.columnconfigure(0, weight=1)
        var_frame.rowconfigure(0, weight=1)
        
        # 创建滚动区域
        canvas = tk.Canvas(var_frame, height=300)
        scrollbar = ttk.Scrollbar(var_frame, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk.Frame(canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # 绑定鼠标滚轮事件
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind("<MouseWheel>", _on_mousewheel)
        
        self.scrollable_frame.columnconfigure(0, weight=1)
    
    def create_control_area(self, parent):
        """创建控制按钮区域"""
        control_frame = ttk.Frame(parent)
        control_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # 添加变量按钮
        add_btn = ttk.Button(control_frame, text="+ 添加变量", command=self.add_variable_row)
        add_btn.grid(row=0, column=0, padx=(0, 10))
        
        # 清空所有变量按钮
        clear_btn = ttk.Button(control_frame, text="清空所有", command=self.clear_all_variables)
        clear_btn.grid(row=0, column=1, padx=(0, 10))
        
        # 预设模板按钮
        template_btn = ttk.Button(control_frame, text="加载模板", command=self.load_template)
        template_btn.grid(row=0, column=2)
    
    def create_generation_area(self, parent):
        """创建生成配置区域"""
        gen_frame = ttk.LabelFrame(parent, text="生成配置", padding="5")
        gen_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # 测试用例数量
        ttk.Label(gen_frame, text="测试用例数量:").grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
        self.test_count_var = tk.StringVar()
        test_count_entry = ttk.Entry(gen_frame, textvariable=self.test_count_var, width=10)
        test_count_entry.grid(row=0, column=1, sticky=tk.W, padx=(0, 20))
        
        # 不生成重复数据选项
        self.no_duplicate_var = tk.BooleanVar()
        no_duplicate_cb = ttk.Checkbutton(gen_frame, text="不生成重复数据", variable=self.no_duplicate_var)
        no_duplicate_cb.grid(row=0, column=2, sticky=tk.W, padx=(0, 20))
        
        # 删除临时文件选项
        self.delete_temp_files_var = tk.BooleanVar()
        delete_temp_cb = ttk.Checkbutton(gen_frame, text="生成zip后删除临时文件", variable=self.delete_temp_files_var)
        delete_temp_cb.grid(row=0, column=3, sticky=tk.W)
        
        # 输出目录
        ttk.Label(gen_frame, text="输出目录:").grid(row=1, column=0, sticky=tk.W, padx=(0, 5), pady=(5, 0))
        self.output_dir_var = tk.StringVar()
        output_dir_entry = ttk.Entry(gen_frame, textvariable=self.output_dir_var, width=30)
        output_dir_entry.grid(row=1, column=1, columnspan=2, sticky=tk.W, padx=(0, 5), pady=(5, 0))
        
        browse_btn = ttk.Button(gen_frame, text="浏览", command=self.browse_output_dir)
        browse_btn.grid(row=1, column=3, padx=(5, 0), pady=(5, 0))
        
        # 生成按钮
        generate_frame = ttk.Frame(parent)
        generate_frame.grid(row=4, column=0, pady=10)
        
        generate_btn = ttk.Button(generate_frame, text="生成测试数据", command=self.generate_data, 
                                style='Accent.TButton')
        generate_btn.grid(row=0, column=0, padx=(0, 10))
        
        preview_btn = ttk.Button(generate_frame, text="预览数据", command=self.preview_data)
        preview_btn.grid(row=0, column=1)
    
    def add_initial_variable_row(self):
        """添加初始变量行"""
        self.add_variable_row()
    
    def add_variable_row(self):
        """添加变量行"""
        row_index = len(self.variable_rows)
        var_row = VariableRow(self.scrollable_frame, row_index, self.remove_variable_row)
        var_row.create_widgets()
        self.variable_rows.append(var_row)
        
        # 更新滚动区域
        self.scrollable_frame.update_idletasks()
    
    def remove_variable_row(self, row_index):
        """移除变量行"""
        if len(self.variable_rows) <= 1:
            messagebox.showwarning("警告", "至少需要保留一个变量！")
            return
        
        # 移除指定行
        if 0 <= row_index < len(self.variable_rows):
            self.variable_rows[row_index].destroy()
            self.variable_rows.pop(row_index)
            
            # 重新排列剩余行的索引
            for i, row in enumerate(self.variable_rows):
                row.update_index(i)
    
    def clear_all_variables(self):
        """清空所有变量"""
        if messagebox.askyesno("确认", "确定要清空所有变量配置吗？"):
            for row in self.variable_rows:
                row.destroy()
            self.variable_rows.clear()
            self.add_initial_variable_row()
    
    def load_template(self):
        """加载预设模板"""
        self.show_template_dialog()
    
    def browse_output_dir(self):
        """浏览输出目录"""
        directory = filedialog.askdirectory(initialdir=self.output_dir_var.get())
        if directory:
            self.output_dir_var.set(directory)
    
    def get_variable_configs(self) -> List[Dict[str, Any]]:
        """获取所有变量配置"""
        configs = []
        for row in self.variable_rows:
            config = row.get_config()
            if config:
                configs.append(config)
        return configs
    
    def preview_data(self):
        """预览数据"""
        try:
            configs = self.get_variable_configs()
            if not configs:
                messagebox.showwarning("警告", "请至少配置一个变量！")
                return
            
            # 获取不重复数据选项
            no_duplicate = self.no_duplicate_var.get()
            
            # 生成预览数据（只生成3组）
            preview_data = self.data_generator.generate_preview_data(configs, 3, no_duplicate)
            
            # 显示预览窗口
            self.show_preview_window(preview_data)
            
        except Exception as e:
            messagebox.showerror("错误", f"预览数据时出错：{str(e)}")
    
    def generate_data(self):
        """生成测试数据"""
        try:
            # 获取配置
            configs = self.get_variable_configs()
            if not configs:
                messagebox.showwarning("警告", "请至少配置一个变量！")
                return
            
            test_count = int(self.test_count_var.get())
            if test_count <= 0:
                messagebox.showwarning("警告", "测试用例数量必须大于0！")
                return
            
            output_dir = self.output_dir_var.get()
            if not output_dir:
                messagebox.showwarning("警告", "请选择输出目录！")
                return
            
            # 获取不重复数据选项
            no_duplicate = self.no_duplicate_var.get()
            
            # 获取删除临时文件选项
            delete_temp_files = self.delete_temp_files_var.get()
            
            # 生成数据
            generated_data = self.data_generator.generate_test_data(configs, test_count, no_duplicate)
            
            # 保存文件
            save_result = self.file_manager.save_test_files(generated_data, output_dir, delete_temp_files=delete_temp_files)
            
            # 询问是否生成处理结果
            if messagebox.askyesno("生成处理结果", "数据生成完成！是否生成处理结果(.out文件)？"):
                self.show_solution_editor(generated_data, output_dir, save_result.get('created_files', []))
            else:
                success_msg = f"成功生成 {test_count} 组测试数据！\n输出目录：{output_dir}"
                if delete_temp_files and 'deleted_temp_files' in save_result:
                    success_msg += f"\n已删除临时文件：{len(save_result['deleted_temp_files'])} 个"
                messagebox.showinfo("成功", success_msg)
            
        except ValueError as e:
            messagebox.showerror("输入错误", str(e))
        except Exception as e:
            messagebox.showerror("错误", f"生成数据时出错：{str(e)}")
    
    def show_preview_window(self, preview_data):
        """显示预览窗口"""
        preview_window = tk.Toplevel(self.root)
        preview_window.title("数据预览")
        preview_window.geometry("600x400")
        
        # 创建文本框显示预览数据
        text_frame = ttk.Frame(preview_window, padding="10")
        text_frame.pack(fill=tk.BOTH, expand=True)
        
        text_widget = tk.Text(text_frame, wrap=tk.WORD)
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 插入预览数据
        for i, data in enumerate(preview_data, 1):
            text_widget.insert(tk.END, f"=== 测试用例 {i} ===\n")
            text_widget.insert(tk.END, data + "\n\n")
        
        text_widget.config(state=tk.DISABLED)
        
        # 关闭按钮
        close_btn = ttk.Button(preview_window, text="关闭", command=preview_window.destroy)
        close_btn.pack(pady=10)
    
    def show_solution_editor(self, test_data: List[str], output_dir: str, input_files: List[str]):
        """显示解题代码编辑器"""
        editor_window = tk.Toplevel(self.root)
        editor_window.title("解题代码编辑器")
        editor_window.geometry("800x600")
        editor_window.transient(self.root)
        editor_window.grab_set()
        
        # 主框架
        main_frame = ttk.Frame(editor_window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 示例数据显示
        example_frame = ttk.LabelFrame(main_frame, text="示例数据（第一个测试用例）", padding="5")
        example_frame.pack(fill=tk.X, pady=(0, 10))
        
        example_text = tk.Text(example_frame, height=6, wrap=tk.WORD, bg="#f0f0f0")
        example_scrollbar = ttk.Scrollbar(example_frame, orient="vertical", command=example_text.yview)
        example_text.configure(yscrollcommand=example_scrollbar.set)
        
        example_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        example_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 显示第一个测试用例
        if test_data:
            example_text.insert(tk.END, test_data[0])
        example_text.config(state=tk.DISABLED)
        
        # 代码编辑区域
        code_frame = ttk.LabelFrame(main_frame, text="解题代码（请根据上面的数据编写处理逻辑）", padding="5")
        code_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        code_text = tk.Text(code_frame, wrap=tk.NONE, font=('Consolas', 10))
        code_scrollbar_v = ttk.Scrollbar(code_frame, orient="vertical", command=code_text.yview)
        code_scrollbar_h = ttk.Scrollbar(code_frame, orient="horizontal", command=code_text.xview)
        code_text.configure(yscrollcommand=code_scrollbar_v.set, xscrollcommand=code_scrollbar_h.set)
        
        code_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        code_scrollbar_v.grid(row=0, column=1, sticky=(tk.N, tk.S))
        code_scrollbar_h.grid(row=1, column=0, sticky=(tk.W, tk.E))
        
        code_frame.grid_rowconfigure(0, weight=1)
        code_frame.grid_columnconfigure(0, weight=1)
        
        # 默认代码模板
        default_code = '''# 解题代码模板\n# 输入数据已经通过input_data变量传入\n# 请根据上面的示例数据编写处理逻辑\n# 最后的print语句会被转换为return语句\n\nlines = input_data.strip().split('\\n')\n# 在这里编写你的解题逻辑\n\n# 示例：\n# result = "your_answer"\n# print(result)'''
        
        code_text.insert(tk.END, default_code)
        
        # 按钮框架
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        # 执行并保存按钮
        execute_btn = ttk.Button(button_frame, text="执行并保存结果", 
                               command=lambda: self.execute_and_save_solution(
                                   code_text.get("1.0", tk.END), test_data, output_dir, editor_window))
        execute_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # 取消按钮
        cancel_btn = ttk.Button(button_frame, text="取消", command=editor_window.destroy)
        cancel_btn.pack(side=tk.RIGHT)
    
    def execute_and_save_solution(self, code: str, test_data: List[str], output_dir: str, editor_window):
        """执行解题代码并保存结果"""
        try:
            # 处理代码：将print语句转换为return语句
            processed_code = self.process_solution_code(code)
            
            # 执行代码获取所有测试用例的结果
            solutions = []
            for i, data in enumerate(test_data):
                try:
                    result = self.execute_solution_code(processed_code, data)
                    solutions.append(str(result))
                except Exception as e:
                    messagebox.showerror("执行错误", f"执行第{i+1}个测试用例时出错：{str(e)}")
                    return
            
            # 获取删除临时文件选项
            delete_temp_files = self.delete_temp_files_var.get()
            
            # 使用文件管理器保存带解答的文件
            save_result = self.file_manager.save_with_solutions(test_data, solutions, output_dir, delete_temp_files=delete_temp_files)
            
            # 关闭编辑器窗口
            editor_window.destroy()
            
            # 显示成功消息
            success_msg = (f"成功生成 {len(test_data)} 组测试数据和解答！\n"
                          f"输出目录：{output_dir}\n"
                          f"文件数量：{save_result['file_count']}")
            
            if delete_temp_files and 'deleted_temp_files' in save_result:
                success_msg += f"\n已删除临时文件：{len(save_result['deleted_temp_files'])} 个"
            
            messagebox.showinfo("成功", success_msg)
            
        except Exception as e:
            messagebox.showerror("错误", f"处理解题代码时出错：{str(e)}")
    
    def process_solution_code(self, code: str) -> str:
        """处理解题代码，将print语句转换为return语句"""
        lines = code.split('\n')
        processed_lines = []
        
        for line in lines:
            stripped_line = line.strip()
            # 查找print语句并转换为return
            if stripped_line.startswith('print(') and stripped_line.endswith(')'):
                # 提取print括号内的内容
                content = stripped_line[6:-1]  # 去掉'print('和')'
                # 保持原有的缩进
                indent = len(line) - len(line.lstrip())
                processed_lines.append(' ' * indent + f'return {content}')
            else:
                processed_lines.append(line)
        
        return '\n'.join(processed_lines)
    
    def execute_solution_code(self, code: str, input_data: str) -> str:
        """执行解题代码"""
        # 创建执行环境
        namespace = {'input_data': input_data}
        
        # 将代码包装成函数
        func_code = "def solve_function(input_data):\n" + '\n'.join(['    ' + line for line in code.split('\n')])
        
        try:
            # 执行函数定义
            exec(func_code, namespace)
            # 调用函数获取结果
            result = namespace['solve_function'](input_data)
            return str(result) if result is not None else ""
        except Exception as e:
            # 如果执行失败，尝试直接执行原始代码（不转换print）
            try:
                # 恢复print语句的原始代码
                original_code = self.restore_print_statements(code)
                # 捕获print输出
                import io
                import sys
                old_stdout = sys.stdout
                sys.stdout = captured_output = io.StringIO()
                
                # 执行原始代码
                exec(original_code, {'input_data': input_data})
                
                # 恢复stdout并获取输出
                sys.stdout = old_stdout
                output = captured_output.getvalue().strip()
                return output
            except Exception:
                raise e
    
    def restore_print_statements(self, code: str) -> str:
        """将return语句恢复为print语句"""
        lines = code.split('\n')
        restored_lines = []
        
        for line in lines:
            stripped_line = line.strip()
            # 查找return语句并转换回print
            if stripped_line.startswith('return '):
                # 提取return后的内容
                content = stripped_line[7:]  # 去掉'return '
                # 保持原有的缩进
                indent = len(line) - len(line.lstrip())
                restored_lines.append(' ' * indent + f'print({content})')
            else:
                restored_lines.append(line)
        
        return '\n'.join(restored_lines)
    
    def show_template_dialog(self):
        """显示模板选择对话框"""
        template_window = tk.Toplevel(self.root)
        template_window.title("选择模板")
        template_window.geometry("500x520")
        template_window.transient(self.root)
        template_window.grab_set()
        
        # 主框架
        main_frame = ttk.Frame(template_window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 模板列表
        ttk.Label(main_frame, text="可用模板:", font=('Arial', 12, 'bold')).pack(anchor=tk.W, pady=(0, 10))
        
        # 创建列表框和滚动条
        list_frame = ttk.Frame(main_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        template_listbox = tk.Listbox(list_frame, height=15)
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=template_listbox.yview)
        template_listbox.configure(yscrollcommand=scrollbar.set)
        
        template_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 加载模板
        all_templates = self.template_manager.get_all_templates()
        template_data = []
        
        # 添加默认模板
        for template in all_templates['default']:
            display_name = f"[默认] {template['name']}"
            template_listbox.insert(tk.END, display_name)
            template_data.append(('default', template))
        
        # 添加用户模板
        for template in all_templates['user']:
            display_name = f"[用户] {template['name']}"
            template_listbox.insert(tk.END, display_name)
            template_data.append(('user', template))
        
        # 描述区域
        desc_frame = ttk.LabelFrame(main_frame, text="模板描述", padding="5")
        desc_frame.pack(fill=tk.X, pady=(0, 10))
        
        desc_text = tk.Text(desc_frame, height=4, wrap=tk.WORD, state=tk.DISABLED)
        desc_text.pack(fill=tk.X)
        
        def on_template_select(event):
            """模板选择事件"""
            selection = template_listbox.curselection()
            if selection:
                index = selection[0]
                template_type, template = template_data[index]
                
                desc_text.config(state=tk.NORMAL)
                desc_text.delete(1.0, tk.END)
                
                description = template.get('description', '无描述')
                variables_info = f"变量数量: {len(template.get('variables', []))}\n"
                
                desc_text.insert(tk.END, f"{description}\n\n{variables_info}")
                
                # 显示变量信息
                for i, var in enumerate(template.get('variables', []), 1):
                    var_info = f"{i}. {var.get('name', '')} ({var.get('data_type', '')})\n"
                    desc_text.insert(tk.END, var_info)
                
                desc_text.config(state=tk.DISABLED)
        
        template_listbox.bind('<<ListboxSelect>>', on_template_select)
        
        # 按钮区域
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X)
        
        def apply_template():
            """应用模板"""
            selection = template_listbox.curselection()
            if not selection:
                messagebox.showwarning("警告", "请选择一个模板！")
                return
            
            index = selection[0]
            template_type, template = template_data[index]
            
            # 清空现有变量
            for row in self.variable_rows:
                row.destroy()
            self.variable_rows.clear()
            
            # 应用模板变量
            for var_config in template.get('variables', []):
                self.add_variable_row_with_config(var_config)
            
            template_window.destroy()
            messagebox.showinfo("成功", f"已应用模板: {template['name']}")
        
        def save_current_as_template():
            """将当前配置保存为模板"""
            self.show_save_template_dialog(template_window)
        
        ttk.Button(button_frame, text="应用模板", command=apply_template).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="保存当前配置为模板", command=save_current_as_template).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="取消", command=template_window.destroy).pack(side=tk.RIGHT)
    
    def add_variable_row_with_config(self, config: Dict[str, Any]):
        """添加带配置的变量行"""
        row_index = len(self.variable_rows)
        var_row = VariableRow(self.scrollable_frame, row_index, self.remove_variable_row)
        var_row.create_widgets()
        
        # 应用配置
        var_row.apply_config(config)
        
        self.variable_rows.append(var_row)
        
        # 更新滚动区域
        self.scrollable_frame.update_idletasks()
    
    def show_save_template_dialog(self, parent_window=None):
        """显示保存模板对话框"""
        save_window = tk.Toplevel(parent_window or self.root)
        save_window.title("保存模板")
        save_window.geometry("400x300")
        save_window.transient(parent_window or self.root)
        save_window.grab_set()
        
        # 主框架
        main_frame = ttk.Frame(save_window, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 模板名称
        ttk.Label(main_frame, text="模板名称:").grid(row=0, column=0, sticky=tk.W, pady=(0, 5))
        name_var = tk.StringVar()
        name_entry = ttk.Entry(main_frame, textvariable=name_var, width=40)
        name_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=(0, 10))
        name_entry.focus()
        
        # 模板描述
        ttk.Label(main_frame, text="模板描述:").grid(row=1, column=0, sticky=(tk.W, tk.N), pady=(0, 5))
        desc_text = tk.Text(main_frame, height=8, width=40, wrap=tk.WORD)
        desc_text.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # 按钮区域
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(10, 0))
        
        def save_template():
            """保存模板"""
            template_name = name_var.get().strip()
            if not template_name:
                messagebox.showwarning("警告", "请输入模板名称！")
                return
            
            description = desc_text.get(1.0, tk.END).strip()
            
            # 获取当前变量配置
            configs = self.get_variable_configs()
            if not configs:
                messagebox.showwarning("警告", "当前没有变量配置可保存！")
                return
            
            # 保存模板
            if self.template_manager.save_user_template(template_name, configs, description):
                messagebox.showinfo("成功", f"模板 '{template_name}' 保存成功！")
                save_window.destroy()
            else:
                messagebox.showerror("错误", "保存模板失败！")
        
        ttk.Button(button_frame, text="保存", command=save_template).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="取消", command=save_window.destroy).pack(side=tk.RIGHT)
    
    def apply_saved_config(self):
        """应用保存的配置"""
        try:
            # 应用测试用例数量
            self.test_count_var.set(self.user_config.get('test_count', '10'))
            
            # 应用不重复数据选项
            self.no_duplicate_var.set(self.user_config.get('no_duplicate', False))
            
            # 应用删除临时文件选项
            self.delete_temp_files_var.set(self.user_config.get('delete_temp_files', False))
            
            # 应用输出目录
            self.output_dir_var.set(self.user_config.get('output_dir', './test_data'))
            
        except Exception as e:
            print(f"应用配置时出错: {e}")
    
    def save_current_config(self):
        """保存当前配置"""
        try:
            current_config = {
                'test_count': self.test_count_var.get(),
                'no_duplicate': self.no_duplicate_var.get(),
                'delete_temp_files': self.delete_temp_files_var.get(),
                'output_dir': self.output_dir_var.get()
            }
            
            self.config_manager.save_config(current_config)
            
        except Exception as e:
            print(f"保存配置时出错: {e}")
    
    def on_closing(self):
        """窗口关闭时的处理"""
        # 保存当前配置
        self.save_current_config()
        # 关闭窗口
        self.root.destroy()