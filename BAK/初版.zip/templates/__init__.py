#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
模板模块
"""