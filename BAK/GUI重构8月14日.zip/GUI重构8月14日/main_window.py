#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主窗口类
功能：提供数据生成器的图形化界面
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import sys
from typing import List, Dict, Any
import threading
import datetime
import glob

# 添加父目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from gui.variable_row import VariableRow
from core.data_generator_core import DataGeneratorCore
from core.file_manager_core import FileManagerCore
from core.config_manager import ConfigManager
from templates.template_manager import TemplateManager
from deepseek_api.deepseek_dialog import DeepSeekDialog, ApiKeyDialog
from deepseek_api.api_key_manager import ApiKeyManager


class MainWindow:
    """主窗口类"""

    def __init__(self, root):
        self.root = root
        self.variable_rows = []

        # 初始化核心组件
        self.data_generator = DataGeneratorCore()
        self.file_manager = FileManagerCore()
        self.template_manager = TemplateManager()
        self.config_manager = ConfigManager()

        # 加载用户配置
        self.user_config = self.config_manager.load_config()

        self.setup_window()
        self.create_widgets()
        self.add_initial_variable_row()

        # 应用保存的配置
        self.apply_saved_config()

    def setup_window(self):
        """设置窗口属性"""
        self.root.title("数据生成器 v2.0")
        self.root.geometry("900x700")
        self.root.resizable(True, True)

        # 绑定窗口关闭事件
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        # 设置窗口图标（如果有的话）
        try:
            # self.root.iconbitmap('icon.ico')
            pass
        except:
            pass

    def create_widgets(self):
        """创建界面组件"""
        # 主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # 配置网格权重
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)

        # 标题
        title_label = ttk.Label(main_frame, text="数据生成器配置", font=('Arial', 14, 'bold'))
        title_label.grid(row=0, column=0, pady=(0, 10), sticky=tk.W)

        # 变量配置区域（可滚动）
        self.create_variable_area(main_frame)

        # 控制按钮区域
        self.create_control_area(main_frame)

        # 生成配置区域
        self.create_generation_area(main_frame)

    def create_variable_area(self, parent):
        """创建变量配置区域"""
        # 变量配置框架
        var_frame = ttk.LabelFrame(parent, text="变量配置", padding="5")
        var_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        var_frame.columnconfigure(0, weight=1)
        var_frame.rowconfigure(0, weight=1)

        # 创建滚动区域
        canvas = tk.Canvas(var_frame, height=300)
        scrollbar = ttk.Scrollbar(var_frame, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk.Frame(canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))

        # 绑定鼠标滚轮事件
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind("<MouseWheel>", _on_mousewheel)

        self.scrollable_frame.columnconfigure(0, weight=1)

    def create_control_area(self, parent):
        """创建控制按钮区域"""
        control_frame = ttk.Frame(parent)
        control_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(0, 10))

        # 添加变量按钮
        add_btn = ttk.Button(control_frame, text="+ 添加变量", command=self.add_variable_row)
        add_btn.grid(row=0, column=0, padx=(0, 10))

        # 清空所有变量按钮
        clear_btn = ttk.Button(control_frame, text="清空所有", command=self.clear_all_variables)
        clear_btn.grid(row=0, column=1, padx=(0, 10))

        # 预设模板按钮
        template_btn = ttk.Button(control_frame, text="加载模板", command=self.load_template)
        template_btn.grid(row=0, column=2)

    def create_generation_area(self, parent):
        """创建生成配置区域"""
        gen_frame = ttk.LabelFrame(parent, text="生成配置", padding="5")
        gen_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
    
        # 测试用例数量
        ttk.Label(gen_frame, text="测试用例数量:").grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
        self.test_count_var = tk.StringVar()
        test_count_entry = ttk.Entry(gen_frame, textvariable=self.test_count_var, width=10)
        test_count_entry.grid(row=0, column=1, sticky=tk.W, padx=(0, 20))
    
        # 不生成重复数据选项
        self.no_duplicate_var = tk.BooleanVar()
        no_duplicate_cb = ttk.Checkbutton(gen_frame, text="不生成重复数据", variable=self.no_duplicate_var)
        no_duplicate_cb.grid(row=0, column=2, sticky=tk.W, padx=(0, 20))
    
        # 删除临时文件选项
        self.delete_temp_files_var = tk.BooleanVar()
        delete_temp_cb = ttk.Checkbutton(gen_frame, text="生成zip后删除临时文件", variable=self.delete_temp_files_var)
        delete_temp_cb.grid(row=0, column=3, sticky=tk.W)
    
        # 输出目录
        ttk.Label(gen_frame, text="输出目录:").grid(row=1, column=0, sticky=tk.W, padx=(0, 5), pady=(5, 0))
        self.output_dir_var = tk.StringVar()
        output_dir_entry = ttk.Entry(gen_frame, textvariable=self.output_dir_var, width=30)
        output_dir_entry.grid(row=1, column=1, columnspan=2, sticky=tk.W, padx=(0, 5), pady=(5, 0))
    
        browse_btn = ttk.Button(gen_frame, text="浏览", command=self.browse_output_dir)
        browse_btn.grid(row=1, column=3, padx=(5, 0), pady=(5, 0))
        
        # 删除按钮和时间选择下拉菜单
        delete_btn = ttk.Button(gen_frame, text="删除", command=self.delete_zip_files)
        delete_btn.grid(row=1, column=4, padx=(5, 0), pady=(5, 0))
        
        # 时间范围下拉菜单
        self.delete_time_var = tk.StringVar(value="一天内")
        time_options = ["一小时内", "一天内", "一周内", "一月内", "一年内"]
        time_combo = ttk.Combobox(gen_frame, textvariable=self.delete_time_var, values=time_options, 
                                 state="readonly", width=8)
        time_combo.grid(row=1, column=5, padx=(5, 0), pady=(5, 0))

        # 生成按钮
        generate_frame = ttk.Frame(parent)
        generate_frame.grid(row=4, column=0, pady=10)

        generate_btn = ttk.Button(generate_frame, text="生成测试数据", command=self.generate_data,
                                  style='Accent.TButton')
        generate_btn.grid(row=0, column=0, padx=(0, 10))

        preview_btn = ttk.Button(generate_frame, text="预览数据", command=self.preview_data)
        preview_btn.grid(row=0, column=1)

    def add_initial_variable_row(self):
        """添加初始变量行"""
        self.add_variable_row()

    def add_variable_row(self):
        """添加变量行"""
        row_index = len(self.variable_rows)
        var_row = VariableRow(self.scrollable_frame, row_index, self.remove_variable_row)
        var_row.create_widgets()
        self.variable_rows.append(var_row)

        # 更新滚动区域
        self.scrollable_frame.update_idletasks()

    def delete_zip_files(self):
        """删除指定时间范围内的zip文件"""
        output_dir = self.output_dir_var.get().strip()
        if not output_dir:
            messagebox.showwarning("警告", "请先选择输出目录")
            return

        if not os.path.exists(output_dir):
            messagebox.showerror("错误", "输出目录不存在")
            return

        # 获取时间范围
        time_range = self.delete_time_var.get()
        now = datetime.datetime.now()

        # 计算时间阈值
        if time_range == "一小时内":
            threshold = now - datetime.timedelta(hours=1)
        elif time_range == "一天内":
            threshold = now - datetime.timedelta(days=1)
        elif time_range == "一周内":
            threshold = now - datetime.timedelta(weeks=1)
        elif time_range == "一月内":
            threshold = now - datetime.timedelta(days=30)
        elif time_range == "一年内":
            threshold = now - datetime.timedelta(days=365)
        else:
            threshold = now - datetime.timedelta(days=1)  # 默认一天内

        try:
            # 查找zip文件
            zip_pattern = os.path.join(output_dir, "*.zip")
            zip_files = glob.glob(zip_pattern)

            # 筛选出符合时间条件的文件
            files_to_delete = []
            for zip_file in zip_files:
                # 获取文件修改时间
                file_mtime = datetime.datetime.fromtimestamp(os.path.getmtime(zip_file))

                # 如果文件在指定时间范围内，则加入删除列表
                if file_mtime >= threshold:
                    files_to_delete.append(zip_file)

            if not files_to_delete:
                messagebox.showinfo("提示", f"在{time_range}没有找到需要删除的zip文件")
                return

            # 显示确认对话框
            file_names = [os.path.basename(f) for f in files_to_delete]
            confirm_msg = f"确定要删除以下 {len(files_to_delete)} 个zip文件吗？\n\n" + "\n".join(file_names)

            if not messagebox.askyesno("确认删除", confirm_msg):
                return

            # 执行删除操作
            deleted_files = []
            failed_files = []

            for zip_file in files_to_delete:
                try:
                    os.remove(zip_file)
                    deleted_files.append(os.path.basename(zip_file))
                except OSError as e:
                    failed_files.append(f"{os.path.basename(zip_file)}: {str(e)}")

            # 显示结果
            if deleted_files:
                success_msg = f"成功删除 {len(deleted_files)} 个文件:\n" + "\n".join(deleted_files)
                if failed_files:
                    success_msg += f"\n\n删除失败 {len(failed_files)} 个文件:\n" + "\n".join(failed_files)
                messagebox.showinfo("删除完成", success_msg)
            elif failed_files:
                messagebox.showerror("删除失败", f"所有文件删除失败:\n" + "\n".join(failed_files))

        except Exception as e:
            messagebox.showerror("错误", f"删除操作失败: {str(e)}")

    def remove_variable_row(self, row_index):
        """移除变量行"""
        if len(self.variable_rows) <= 1:
            messagebox.showwarning("警告", "至少需要保留一个变量！")
            return

        # 移除指定行
        if 0 <= row_index < len(self.variable_rows):
            self.variable_rows[row_index].destroy()
            self.variable_rows.pop(row_index)

            # 重新排列剩余行的索引
            for i, row in enumerate(self.variable_rows):
                row.update_index(i)

    def clear_all_variables(self):
        """清空所有变量"""
        if messagebox.askyesno("确认", "确定要清空所有变量配置吗？"):
            for row in self.variable_rows:
                row.destroy()
            self.variable_rows.clear()
            self.add_initial_variable_row()

    def load_template(self):
        """加载预设模板"""
        self.show_template_dialog()

    def browse_output_dir(self):
        """浏览输出目录"""
        directory = filedialog.askdirectory(initialdir=self.output_dir_var.get())
        if directory:
            self.output_dir_var.set(directory)

    def get_variable_configs(self) -> List[Dict[str, Any]]:
        """获取所有变量配置"""
        configs = []
        for row in self.variable_rows:
            config = row.get_config()
            if config:
                configs.append(config)
        return configs

    def preview_data(self):
        """预览数据"""
        try:
            configs = self.get_variable_configs()
            if not configs:
                messagebox.showwarning("警告", "请至少配置一个变量！")
                return

            # 获取不重复数据选项
            no_duplicate = self.no_duplicate_var.get()

            # 生成预览数据（只生成3组）
            preview_data = self.data_generator.generate_preview_data(configs, 3, no_duplicate)

            # 显示预览窗口
            self.show_preview_window(preview_data)

        except Exception as e:
            messagebox.showerror("错误", f"预览数据时出错：{str(e)}")

    def generate_data(self):
        """生成测试数据"""
        try:
            # 获取配置
            configs = self.get_variable_configs()
            if not configs:
                messagebox.showwarning("警告", "请至少配置一个变量！")
                return

            test_count = int(self.test_count_var.get())
            if test_count <= 0:
                messagebox.showwarning("警告", "测试用例数量必须大于0！")
                return

            output_dir = self.output_dir_var.get()
            if not output_dir:
                messagebox.showwarning("警告", "请选择输出目录！")
                return

            # 获取不重复数据选项
            no_duplicate = self.no_duplicate_var.get()

            # 获取删除临时文件选项
            delete_temp_files = self.delete_temp_files_var.get()

            # 生成数据
            generated_data = self.data_generator.generate_test_data(configs, test_count, no_duplicate)

            # 保存文件
            save_result = self.file_manager.save_test_files(generated_data, output_dir,
                                                            delete_temp_files=delete_temp_files)

            # 询问是否生成处理结果
            if messagebox.askyesno("生成处理结果", "数据生成完成！是否生成处理结果(.out文件)？"):
                self.show_solution_editor(generated_data, output_dir, save_result.get('created_files', []))
            else:
                success_msg = f"成功生成 {test_count} 组测试数据！\n输出目录：{output_dir}"
                if delete_temp_files and 'deleted_temp_files' in save_result:
                    success_msg += f"\n已删除临时文件：{len(save_result['deleted_temp_files'])} 个"
                messagebox.showinfo("成功", success_msg)

        except ValueError as e:
            messagebox.showerror("输入错误", str(e))
        except Exception as e:
            messagebox.showerror("错误", f"生成数据时出错：{str(e)}")

    def show_preview_window(self, preview_data):
        """显示预览窗口"""
        preview_window = tk.Toplevel(self.root)
        preview_window.title("数据预览")
        preview_window.geometry("600x400")

        # 创建文本框显示预览数据
        text_frame = ttk.Frame(preview_window, padding="10")
        text_frame.pack(fill=tk.BOTH, expand=True)

        text_widget = tk.Text(text_frame, wrap=tk.WORD)
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)

        text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # 插入预览数据
        for i, data in enumerate(preview_data, 1):
            text_widget.insert(tk.END, f"=== 测试用例 {i} ===\n")
            text_widget.insert(tk.END, data + "\n\n")

        text_widget.config(state=tk.DISABLED)

        # 关闭按钮
        close_btn = ttk.Button(preview_window, text="关闭", command=preview_window.destroy)
        close_btn.pack(pady=10)

    def show_solution_editor(self, test_data: List[str], output_dir: str, input_files: List[str]):
        """显示解题代码编辑器"""
        from .code_editor import show_code_editor

        # 准备模板代码
        template_code = '''# 解题代码模板
# 输入数据已经通过input_data变量传入
# 请根据下面的示例数据编写处理逻辑
# 最后的print语句会被转换为return语句

lines = input_data.strip().split('\\n')
# 在这里编写你的解题逻辑

# 示例：
# result = "your_answer"
# print(result)'''

        # 创建一个自定义的编辑器窗口来集成示例数据显示和代码编辑
        editor_window = tk.Toplevel(self.root)
        editor_window.title("解题代码编辑器")
        editor_window.geometry("900x700")
        editor_window.transient(self.root)
        editor_window.grab_set()

        # 主框架
        main_frame = ttk.Frame(editor_window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 示例数据显示
        example_frame = ttk.LabelFrame(main_frame, text="示例数据（第一个测试用例）", padding="5")
        example_frame.pack(fill=tk.X, pady=(0, 10))

        example_text = tk.Text(example_frame, height=6, wrap=tk.WORD, bg="#f0f0f0")
        example_scrollbar = ttk.Scrollbar(example_frame, orient="vertical", command=example_text.yview)
        example_text.configure(yscrollcommand=example_scrollbar.set)

        example_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        example_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # 显示第一个测试用例
        if test_data:
            example_text.insert(tk.END, test_data[0])
        example_text.config(state=tk.DISABLED)

        # 代码编辑区域框架
        code_frame = ttk.LabelFrame(main_frame, text="解题代码（请根据上面的数据编写处理逻辑）", padding="5")
        code_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        # 使用我们的代码编辑器组件
        from .code_editor import CodeEditor

        # 创建代码编辑器实例（嵌入到现有窗口中）
        code_editor = CodeEditor(
            parent=code_frame,
            title="",  # 不需要标题，因为已经在LabelFrame中
            initial_code="",
            template_code=template_code,
            width=0,  # 将使用父容器的大小
            height=0
        )

        # 创建嵌入式编辑器（不是弹窗）
        code_editor.create_embedded_editor(code_frame)

        # 按钮框架
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))

        # 执行并保存按钮
        execute_btn = ttk.Button(button_frame, text="执行并保存结果",
                                 command=lambda: self.execute_and_save_solution(
                                     code_editor.get_code(), test_data, output_dir, editor_window))
        execute_btn.pack(side=tk.LEFT, padx=(0, 10))

        # 问问DeepSeek按钮
        deepseek_btn = ttk.Button(button_frame, text="问问DeepSeek",
                                  command=lambda: self.ask_deepseek_with_editor(code_editor,
                                                                                test_data[0] if test_data else ""))
        deepseek_btn.pack(side=tk.LEFT, padx=(0, 10))

        # 取消按钮
        cancel_btn = ttk.Button(button_frame, text="取消", command=editor_window.destroy)
        cancel_btn.pack(side=tk.RIGHT)

        # 保存编辑器引用，用于DeepSeek功能
        self.current_code_editor = code_editor

    def ask_deepseek_with_editor(self, code_editor, example_data: str):
        """使用代码编辑器的DeepSeek功能"""
        try:
            current_code = code_editor.get_code()

            # 获取API密钥
            api_key = self.get_deepseek_api_key()
            if not api_key:
                return

            # 获取问题描述
            problem_description = self.get_problem_description()
            if not problem_description:
                return

            # 创建DeepSeek对话框 - 传递正确的4个参数
            dialog = DeepSeekDialog(self.root, api_key, problem_description, example_data)
            dialog.start_generation()  # 启动代码生成

            # 注意：DeepSeekDialog 不返回结果，它是一个独立的对话窗口

        except ImportError as e:
            messagebox.showerror("导入错误",
                                 f"DeepSeek功能不可用，缺少模块：{str(e)}\n\n请检查以下模块是否已安装：\n- deepseek_dialog\n- 相关依赖库")
        except ModuleNotFoundError as e:
            messagebox.showerror("模块未找到",
                                 f"找不到模块：{str(e)}\n\n请确保以下文件存在：\n- gui/deepseek_dialog.py\n- deepseek_api/deepseek_dialog.py")
        except Exception as e:
            messagebox.showerror("错误", f"调用DeepSeek时出错：{str(e)}")

    def execute_and_save_solution(self, code: str, test_data: List[str], output_dir: str, editor_window):
        """执行解题代码并保存结果"""
        try:
            # 处理代码：将print语句转换为return语句
            processed_code = self.process_solution_code(code)

            # 执行代码获取所有测试用例的结果
            solutions = []
            for i, data in enumerate(test_data):
                try:
                    result = self.execute_solution_code(processed_code, data)
                    solutions.append(str(result))
                except Exception as e:
                    messagebox.showerror("执行错误", f"执行第{i + 1}个测试用例时出错：{str(e)}")
                    return

            # 获取删除临时文件选项
            delete_temp_files = self.delete_temp_files_var.get()

            # 使用文件管理器保存带解答的文件
            save_result = self.file_manager.save_with_solutions(test_data, solutions, output_dir,
                                                                delete_temp_files=delete_temp_files)

            # 关闭编辑器窗口
            editor_window.destroy()

            # 显示成功消息
            success_msg = (f"成功生成 {len(test_data)} 组测试数据和解答！\n"
                           f"输出目录：{output_dir}\n"
                           f"文件数量：{save_result['file_count']}")

            if delete_temp_files and 'deleted_temp_files' in save_result:
                success_msg += f"\n已删除临时文件：{len(save_result['deleted_temp_files'])} 个"

            messagebox.showinfo("成功", success_msg)

        except Exception as e:
            messagebox.showerror("错误", f"处理解题代码时出错：{str(e)}")

    def process_solution_code(self, code: str) -> str:
        """处理解题代码，将print语句转换为return语句"""
        lines = code.split('\n')
        has_function = False
        has_main = False

        # 检测是否有函数定义和main函数
        for line in lines:
            stripped_line = line.strip()
            if stripped_line.startswith('def ') and not stripped_line.startswith('def #'):
                has_function = True
                if 'main(' in stripped_line:
                    has_main = True

        # 如果有函数但没有main函数，抛出异常
        if has_function and not has_main:
            raise Exception("代码包含函数定义但缺少main函数入口点。请添加main()函数作为程序入口。")

        # 如果包含函数，直接返回原始代码，不做任何转换
        if has_function:
            return code

        # 对于非函数代码，进行print到return的转换
        processed_lines = []
        for line in lines:
            stripped_line = line.strip()
            # 跳过注释行
            if stripped_line.startswith('#'):
                processed_lines.append(line)
                continue

            # 查找print语句并转换为return
            if stripped_line.startswith('print(') and stripped_line.endswith(')'):
                # 提取print括号内的内容
                content = stripped_line[6:-1]  # 去掉'print('和')'
                # 保持原有的缩进
                indent = len(line) - len(line.lstrip())
                processed_lines.append(' ' * indent + f'return {content}')
            else:
                processed_lines.append(line)

        return '\n'.join(processed_lines)

    def execute_solution_code(self, code: str, input_data: str) -> str:
        """执行解题代码"""
        # 创建执行环境
        namespace = {'input_data': input_data}

        # 检测是否包含函数定义
        has_function = any(line.strip().startswith('def ') and not line.strip().startswith('def #')
                           for line in code.split('\n'))

        if has_function:
            # 如果包含函数，直接执行原始代码并调用main函数
            try:
                # 执行代码定义所有函数
                exec(code, namespace)

                # 调用main函数并获取返回值
                if 'main' in namespace and callable(namespace['main']):
                    result = namespace['main']()
                    return str(result) if result is not None else ""
                else:
                    raise Exception("找不到main函数")

            except Exception as e:
                # 如果执行失败，尝试捕获print输出作为备选方案
                try:
                    import io
                    import sys
                    old_stdout = sys.stdout
                    sys.stdout = captured_output = io.StringIO()

                    # 重新执行代码
                    exec(code, {'input_data': input_data})

                    # 如果有main函数，调用它
                    namespace_backup = {'input_data': input_data}
                    exec(code, namespace_backup)
                    if 'main' in namespace_backup and callable(namespace_backup['main']):
                        namespace_backup['main']()

                    # 恢复stdout并获取输出
                    sys.stdout = old_stdout
                    output = captured_output.getvalue().strip()
                    return output if output else str(e)
                except Exception:
                    raise e
        else:
            # 原有的简单代码执行逻辑（已经过process_solution_code处理）
            # 将代码包装成函数
            func_code = "def solve_function(input_data):\n" + '\n'.join(['    ' + line for line in code.split('\n')])

            try:
                # 执行函数定义
                exec(func_code, namespace)
                # 调用函数获取结果
                result = namespace['solve_function'](input_data)
                return str(result) if result is not None else ""
            except Exception as e:
                # 如果执行失败，尝试直接执行原始代码（不转换print）
                try:
                    # 恢复print语句的原始代码
                    original_code = self.restore_print_statements(code)
                    # 捕获print输出
                    import io
                    import sys
                    old_stdout = sys.stdout
                    sys.stdout = captured_output = io.StringIO()

                    # 执行原始代码
                    exec(original_code, {'input_data': input_data})

                    # 恢复stdout并获取输出
                    sys.stdout = old_stdout
                    output = captured_output.getvalue().strip()
                    return output
                except Exception:
                    raise e

    def restore_print_statements(self, code: str) -> str:
        """将return语句恢复为print语句"""
        lines = code.split('\n')
        restored_lines = []

        for line in lines:
            stripped_line = line.strip()
            # 查找return语句并转换回print
            if stripped_line.startswith('return '):
                # 提取return后的内容
                content = stripped_line[7:]  # 去掉'return '
                # 保持原有的缩进
                indent = len(line) - len(line.lstrip())
                restored_lines.append(' ' * indent + f'print({content})')
            else:
                restored_lines.append(line)

        return '\n'.join(restored_lines)

    def show_template_dialog(self):
        """显示模板选择对话框"""
        template_window = tk.Toplevel(self.root)
        template_window.title("选择模板")
        template_window.geometry("500x520")
        template_window.transient(self.root)
        template_window.grab_set()

        # 主框架
        main_frame = ttk.Frame(template_window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 模板列表
        ttk.Label(main_frame, text="可用模板:", font=('Arial', 12, 'bold')).pack(anchor=tk.W, pady=(0, 10))

        # 创建列表框和滚动条
        list_frame = ttk.Frame(main_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        template_listbox = tk.Listbox(list_frame, height=15)
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=template_listbox.yview)
        template_listbox.configure(yscrollcommand=scrollbar.set)

        template_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # 加载模板
        all_templates = self.template_manager.get_all_templates()
        template_data = []

        # 添加默认模板
        for template in all_templates['default']:
            display_name = f"[默认] {template['name']}"
            template_listbox.insert(tk.END, display_name)
            template_data.append(('default', template))

        # 添加用户模板
        for template in all_templates['user']:
            display_name = f"[用户] {template['name']}"
            template_listbox.insert(tk.END, display_name)
            template_data.append(('user', template))

        # 描述区域
        desc_frame = ttk.LabelFrame(main_frame, text="模板描述", padding="5")
        desc_frame.pack(fill=tk.X, pady=(0, 10))

        desc_text = tk.Text(desc_frame, height=4, wrap=tk.WORD, state=tk.DISABLED)
        desc_text.pack(fill=tk.X)

        def on_template_select(event):
            """模板选择事件"""
            selection = template_listbox.curselection()
            if selection:
                index = selection[0]
                template_type, template = template_data[index]

                desc_text.config(state=tk.NORMAL)
                desc_text.delete(1.0, tk.END)

                description = template.get('description', '无描述')
                variables_info = f"变量数量: {len(template.get('variables', []))}\n"

                desc_text.insert(tk.END, f"{description}\n\n{variables_info}")

                # 显示变量信息
                for i, var in enumerate(template.get('variables', []), 1):
                    var_info = f"{i}. {var.get('name', '')} ({var.get('data_type', '')})\n"
                    desc_text.insert(tk.END, var_info)

                desc_text.config(state=tk.DISABLED)

        template_listbox.bind('<<ListboxSelect>>', on_template_select)

        # 按钮区域
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X)

        def apply_template():
            """应用模板"""
            selection = template_listbox.curselection()
            if not selection:
                messagebox.showwarning("警告", "请选择一个模板！")
                return

            index = selection[0]
            template_type, template = template_data[index]

            # 清空现有变量
            for row in self.variable_rows:
                row.destroy()
            self.variable_rows.clear()

            # 应用模板变量
            for var_config in template.get('variables', []):
                self.add_variable_row_with_config(var_config)

            template_window.destroy()
            messagebox.showinfo("成功", f"已应用模板: {template['name']}")

        def save_current_as_template():
            """将当前配置保存为模板"""
            self.show_save_template_dialog(template_window)

        ttk.Button(button_frame, text="应用模板", command=apply_template).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="保存当前配置为模板", command=save_current_as_template).pack(side=tk.LEFT,
                                                                                                   padx=(0, 10))
        ttk.Button(button_frame, text="取消", command=template_window.destroy).pack(side=tk.RIGHT)

    def add_variable_row_with_config(self, config: Dict[str, Any]):
        """添加带配置的变量行"""
        row_index = len(self.variable_rows)
        var_row = VariableRow(self.scrollable_frame, row_index, self.remove_variable_row)
        var_row.create_widgets()

        # 应用配置
        var_row.apply_config(config)

        self.variable_rows.append(var_row)

        # 更新滚动区域
        self.scrollable_frame.update_idletasks()

    def show_save_template_dialog(self, parent_window=None):
        """显示保存模板对话框"""
        save_window = tk.Toplevel(parent_window or self.root)
        save_window.title("保存模板")
        save_window.geometry("400x300")
        save_window.transient(parent_window or self.root)
        save_window.grab_set()

        # 主框架
        main_frame = ttk.Frame(save_window, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 模板名称
        ttk.Label(main_frame, text="模板名称:").grid(row=0, column=0, sticky=tk.W, pady=(0, 5))
        name_var = tk.StringVar()
        name_entry = ttk.Entry(main_frame, textvariable=name_var, width=40)
        name_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=(0, 10))
        name_entry.focus()

        # 模板描述
        ttk.Label(main_frame, text="模板描述:").grid(row=1, column=0, sticky=(tk.W, tk.N), pady=(0, 5))
        desc_text = tk.Text(main_frame, height=8, width=40, wrap=tk.WORD)
        desc_text.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))

        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)

        # 按钮区域
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(10, 0))

        def save_template():
            """保存模板"""
            template_name = name_var.get().strip()
            if not template_name:
                messagebox.showwarning("警告", "请输入模板名称！")
                return

            description = desc_text.get(1.0, tk.END).strip()

            # 获取当前变量配置
            configs = self.get_variable_configs()
            if not configs:
                messagebox.showwarning("警告", "当前没有变量配置可保存！")
                return

            # 保存模板
            if self.template_manager.save_user_template(template_name, configs, description):
                messagebox.showinfo("成功", f"模板 '{template_name}' 保存成功！")
                save_window.destroy()
            else:
                messagebox.showerror("错误", "保存模板失败！")

        ttk.Button(button_frame, text="保存", command=save_template).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="取消", command=save_window.destroy).pack(side=tk.RIGHT)

    def apply_saved_config(self):
        """应用保存的配置"""
        try:
            # 应用测试用例数量
            self.test_count_var.set(self.user_config.get('test_count', '10'))

            # 应用不重复数据选项
            self.no_duplicate_var.set(self.user_config.get('no_duplicate', False))

            # 应用删除临时文件选项
            self.delete_temp_files_var.set(self.user_config.get('delete_temp_files', False))

            # 应用输出目录
            self.output_dir_var.set(self.user_config.get('output_dir', './test_data'))

        except Exception as e:
            print(f"应用配置时出错: {e}")

    def save_current_config(self):
        """保存当前配置"""
        try:
            current_config = {
                'test_count': self.test_count_var.get(),
                'no_duplicate': self.no_duplicate_var.get(),
                'delete_temp_files': self.delete_temp_files_var.get(),
                'output_dir': self.output_dir_var.get()
            }

            self.config_manager.save_config(current_config)

        except Exception as e:
            print(f"保存配置时出错: {e}")

    def on_closing(self):
        """窗口关闭时的处理"""
        # 保存当前配置
        self.save_current_config()
        # 关闭窗口
        self.root.destroy()

    def ask_deepseek(self, code_text, test_data: str):
        """调用DeepSeek生成代码"""
        print("[DEBUG] ask_deepseek() 被调用")
        try:
            # 获取API密钥
            api_key = self.get_deepseek_api_key()
            if not api_key:
                print("[DEBUG] 未获取到API密钥，退出")
                return

            # 获取题目描述
            problem_description = self.get_problem_description()
            if not problem_description:
                print("[DEBUG] 未获取到题目描述，退出")
                return

            print("[DEBUG] 创建DeepSeekDialog实例")
            # 创建DeepSeek对话窗口
            dialog = DeepSeekDialog(
                parent=self.root,
                api_key=api_key,
                problem_description=problem_description,
                test_data=test_data
            )
            print("[DEBUG] 调用dialog.start_generation()")
            dialog.start_generation()

        except Exception as e:
            print(f"[DEBUG] ask_deepseek出错: {str(e)}")
            messagebox.showerror("错误", f"调用DeepSeek时出错：{str(e)}")

    def get_deepseek_api_key(self) -> str:
        """获取DeepSeek API密钥"""
        # 使用新的API密钥管理器
        api_key = ApiKeyManager.get_api_key()
        if api_key:
            return api_key

        # 如果没有保存的密钥，弹出输入对话框
        dialog = ApiKeyDialog(self.root)
        api_key = dialog.show()

        return api_key

    def get_problem_description(self) -> str:
        """获取题目描述"""
        # 创建题目描述输入对话框
        dialog = tk.Toplevel(self.root)
        dialog.title("输入题目描述")
        dialog.geometry("600x600")
        dialog.transient(self.root)
        dialog.grab_set()

        # 主框架
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 说明标签
        info_label = ttk.Label(main_frame, text="请输入题目描述，这将帮助DeepSeek更好地理解问题：")
        info_label.pack(pady=(0, 10))

        # 文本输入框
        text_frame = ttk.Frame(main_frame)
        text_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 20))

        text_widget = tk.Text(text_frame, wrap=tk.WORD, font=('Microsoft YaHei', 10))
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)

        text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # 默认提示文本
        placeholder = "例如：\n给定一个整数数组和一个目标值，找出数组中两个数的和等于目标值的所有组合。\n\n输入格式：\n第一行包含数组长度n和目标值target\n第二行包含n个整数\n\n输出格式：\n输出所有满足条件的数对"
        text_widget.insert(tk.END, placeholder)
        text_widget.focus()

        # 按钮框架
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X)

        result = {'description': None}

        def ok_clicked():
            description = text_widget.get("1.0", tk.END).strip()
            if not description or description == placeholder.strip():
                messagebox.showerror("错误", "请输入题目描述")
                return
            result['description'] = description
            dialog.destroy()

        def cancel_clicked():
            result['description'] = None
            dialog.destroy()

        # 确定按钮
        ok_btn = ttk.Button(button_frame, text="确定", command=ok_clicked)
        ok_btn.pack(side=tk.RIGHT, padx=(10, 0))

        # 取消按钮
        cancel_btn = ttk.Button(button_frame, text="取消", command=cancel_clicked)
        cancel_btn.pack(side=tk.RIGHT)

        # 绑定快捷键
        dialog.bind('<Control-Return>', lambda e: ok_clicked())
        dialog.bind('<Escape>', lambda e: cancel_clicked())

        # 等待对话框关闭
        dialog.wait_window()

        return result['description']
