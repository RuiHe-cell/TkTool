#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动补全功能模块
功能：为代码编辑器提供智能自动补全功能
"""

import tkinter as tk
import keyword
import builtins
import re


class AutoCompletion:
    """自动补全类"""
    
    def __init__(self, text_widget, language="python"):
        """
        初始化自动补全功能
        
        Args:
            text_widget: 文本控件
            language: 编程语言类型
        """
        self.text_widget = text_widget
        self.language = language
        
        # 自动补全相关属性
        self.completion_window = None
        self.completion_listbox = None
        self.completion_candidates = []
        self.completion_start_pos = None
        self.completion_prefix = ""
        
        # Python 关键字和内置函数
        self.python_keywords = keyword.kwlist
        self.python_builtins = dir(builtins)
    
    def show_completion(self):
        """显示自动补全窗口"""
        try:
            # 获取当前光标位置
            cursor_pos = self.text_widget.index(tk.INSERT)
            line, col = map(int, cursor_pos.split('.'))

            # 获取当前行内容
            line_start = f"{line}.0"
            line_end = f"{line}.end"
            line_content = self.text_widget.get(line_start, line_end)

            # 检查是否是对象方法调用（如 a.）
            dot_pos = line_content.rfind('.', 0, col)
            if dot_pos != -1 and dot_pos < col:
                # 找到点操作符，获取对象名和方法前缀
                obj_start = dot_pos - 1
                while obj_start >= 0 and (line_content[obj_start].isalnum() or line_content[obj_start] == '_'):
                    obj_start -= 1
                obj_start += 1

                object_name = line_content[obj_start:dot_pos]
                method_prefix = line_content[dot_pos + 1:col]

                # 获取对象方法补全候选项
                candidates = self.get_object_method_candidates(object_name, method_prefix, line_content)

                if candidates:
                    # 保存补全信息
                    self.completion_prefix = method_prefix
                    self.completion_start_pos = f"{line}.{dot_pos + 1}"
                    self.completion_candidates = candidates
                    # 创建或更新补全窗口
                    self.create_completion_window(cursor_pos)
                    return
                else:
                    self.hide_completion()
                    return

            # 常规标识符补全
            # 找到当前单词的开始位置
            word_start = col
            while word_start > 0 and (line_content[word_start - 1].isalnum() or line_content[word_start - 1] == '_'):
                word_start -= 1

            # 获取当前输入的前缀
            prefix = line_content[word_start:col]

            if len(prefix) < 1:  # 至少输入1个字符才显示补全
                self.hide_completion()
                return

            # 获取补全候选项
            candidates = self.get_completion_candidates(prefix)

            if not candidates:
                self.hide_completion()
                return

            # 保存补全信息
            self.completion_prefix = prefix
            self.completion_start_pos = f"{line}.{word_start}"
            self.completion_candidates = candidates

            # 创建或更新补全窗口
            self.create_completion_window(cursor_pos)

        except Exception as e:
            print(f"补全显示错误: {e}")
            self.hide_completion()
    
    def get_object_method_candidates(self, object_name, method_prefix, full_line):
        """获取对象方法补全候选项"""
        candidates = []
        method_prefix_lower = method_prefix.lower()

        # 尝试分析对象类型
        object_type = self.infer_object_type(object_name, full_line)

        # 根据对象类型获取方法
        methods = self.get_methods_for_type(object_type)

        for method_name, method_info in methods.items():
            if method_name.lower().startswith(method_prefix_lower):
                candidates.append((method_name, method_info['type'], method_info.get('auto_parentheses', False)))

        # 排序候选项：常用方法优先
        candidates.sort(key=lambda x: (x[1] != "method", x[0].lower()))

        return candidates[:15]  # 限制显示数量
    
    def infer_object_type(self, object_name, full_line):
        """推断对象类型"""
        # 获取整个文件内容进行分析
        try:
            code = self.text_widget.get(1.0, tk.END)
            lines = code.split('\n')
    
            # 首先检查是否是导入的模块
            for line in lines:
                line = line.strip()
                # 检查 import module 语句
                if line.startswith('import ') and object_name in line:
                    # 处理 "import random" 或 "import random, os" 等情况
                    import_parts = line.replace('import ', '').split(',')
                    for part in import_parts:
                        module_name = part.strip()
                        if module_name == object_name:
                            return f"module_{object_name}"
                    
                # 检查 from module import * 语句
                elif line.startswith('from ') and 'import' in line:
                    # 处理 "from random import *" 等情况
                    if f'from {object_name} import' in line:
                        return f"module_{object_name}"
                    
                # 检查 import module as alias 语句
                elif 'import' in line and ' as ' in line:
                    # 处理 "import random as rd" 等情况
                    parts = line.split(' as ')
                    if len(parts) == 2:
                        import_part = parts[0].strip()
                        alias = parts[1].strip()
                        if alias == object_name and 'import' in import_part:
                            module_name = import_part.replace('import ', '').strip()
                            return f"module_{module_name}"
    
            # 查找变量赋值语句
            for line in lines:
                line = line.strip()
                if f"{object_name} = " in line:
                    # 简单的类型推断
                    if '"' in line or "'" in line:
                        return "str"
                    elif "[" in line and "]" in line:
                        return "list"
                    elif "{" in line and "}" in line:
                        if ":" in line:
                            return "dict"
                        else:
                            return "set"
                    elif line.endswith(".split(") or ".strip(" in line:
                        return "str"
                    elif "int(" in line:
                        return "int"
                    elif "float(" in line:
                        return "float"
                    elif "range(" in line:
                        return "range"
    
            # 如果没有找到明确的赋值，返回通用类型
            return "object"
    
        except:
            return "object"

    def get_methods_for_type(self, object_type):
        """根据类型获取可用方法"""
        methods = {}

        # 处理模块类型
        if object_type.startswith("module_"):
            module_name = object_type.replace("module_", "")

            try:
                # 动态导入模块
                import importlib
                module = importlib.import_module(module_name)

                # 获取模块的所有属性
                for attr_name in dir(module):
                    # 过滤私有属性
                    if not attr_name.startswith('_'):
                        attr = getattr(module, attr_name)

                        # 判断属性类型
                        if callable(attr):
                            if hasattr(attr, '__self__'):
                                # 绑定方法
                                methods[attr_name] = {'type': 'method', 'auto_parentheses': True}
                            else:
                                # 函数
                                methods[attr_name] = {'type': 'function', 'auto_parentheses': True}
                        else:
                            # 属性或常量
                            methods[attr_name] = {'type': 'attribute', 'auto_parentheses': False}

            except ImportError:
                # 如果模块无法导入，回退到手动定义的常见模块
                # 这里可以保留一些核心模块的手动定义作为备选
                pass

            return methods
    
    def get_completion_candidates(self, prefix):
        """获取补全候选项"""
        candidates = []
        prefix_lower = prefix.lower()

        # Python 关键字
        for keyword_item in self.python_keywords:
            if keyword_item.lower().startswith(prefix_lower):
                candidates.append((keyword_item, "keyword", False))

        # Python 内置函数
        for builtin in self.python_builtins:
            if not builtin.startswith('_') and builtin.lower().startswith(prefix_lower):
                # 内置函数需要自动添加括号
                auto_parentheses = builtin in ['print', 'len', 'str', 'int', 'float', 'list', 'dict', 'set', 'tuple', 'range', 'enumerate', 'zip', 'map', 'filter', 'sorted', 'max', 'min', 'sum', 'abs', 'round', 'type', 'isinstance', 'hasattr', 'getattr', 'setattr', 'input', 'open']
                candidates.append((builtin, "builtin", auto_parentheses))

        # 当前文件中的标识符
        file_identifiers = self.extract_identifiers_from_code()
        for identifier in file_identifiers:
            if identifier.lower().startswith(prefix_lower) and identifier != prefix:
                candidates.append((identifier, "identifier", False))

        # 去重并排序
        unique_candidates = list(set(candidates))
        unique_candidates.sort(key=lambda x: (x[1] != "keyword", x[1] != "builtin", x[0].lower()))

        return unique_candidates[:20]  # 限制显示数量
    
    def extract_identifiers_from_code(self):
        """从当前代码中提取标识符"""
        try:
            code = self.text_widget.get(1.0, tk.END)
            # 使用正则表达式提取标识符
            pattern = r'\b[a-zA-Z_][a-zA-Z0-9_]*\b'
            identifiers = re.findall(pattern, code)
            # 过滤掉关键字和内置函数
            filtered = []
            for identifier in identifiers:
                if (identifier not in self.python_keywords and
                        identifier not in self.python_builtins and
                        len(identifier) > 1):
                    filtered.append(identifier)
            return list(set(filtered))
        except:
            return []
    
    def create_completion_window(self, cursor_pos):
        """创建自动补全窗口"""
        if self.completion_window:
            self.completion_window.destroy()

        # 创建顶层窗口
        self.completion_window = tk.Toplevel(self.text_widget)
        self.completion_window.wm_overrideredirect(True)
        self.completion_window.configure(bg='white', relief='solid', bd=1)

        # 创建列表框
        self.completion_listbox = tk.Listbox(
            self.completion_window,
            height=min(10, len(self.completion_candidates)),
            font=('Consolas', 9),
            selectmode=tk.SINGLE,
            bg='white',
            fg='black',
            selectbackground='#0078d4',
            selectforeground='white',
            relief='flat',
            bd=0
        )
        self.completion_listbox.pack(fill=tk.BOTH, expand=True)

        # 填充候选项
        for candidate_info in self.completion_candidates:
            if len(candidate_info) == 3:
                candidate, candidate_type, auto_parentheses = candidate_info
            else:
                candidate, candidate_type = candidate_info
                auto_parentheses = False
            
            # 根据类型显示不同的图标或标识
            if candidate_type == "method":
                display_text = f"🔧 {candidate}"
            elif candidate_type == "attribute":
                display_text = f"📋 {candidate}"
            elif candidate_type == "builtin":
                display_text = f"⚙️ {candidate}"
            elif candidate_type == "keyword":
                display_text = f"🔑 {candidate}"
            else:
                display_text = f"📝 {candidate}"
                
            self.completion_listbox.insert(tk.END, display_text)

        # 选中第一项
        if self.completion_candidates:
            self.completion_listbox.selection_set(0)

        # 绑定补全窗口的键盘事件
        self.completion_listbox.bind('<Double-Button-1>', lambda e: self.accept_completion())
        self.completion_listbox.bind('<Return>', lambda e: self.accept_completion())
        self.completion_listbox.bind('<Tab>', lambda e: self.accept_completion())
        self.completion_listbox.bind('<Escape>', lambda e: self.hide_completion())
        self.completion_listbox.bind('<Up>', self.handle_listbox_navigation)
        self.completion_listbox.bind('<Down>', self.handle_listbox_navigation)

        # 计算窗口位置
        self.position_completion_window(cursor_pos)
    
    def handle_listbox_navigation(self, event):
        """处理补全列表框的导航"""
        current_selection = self.completion_listbox.curselection()
        if not current_selection:
            self.completion_listbox.selection_set(0)
            return "break"

        current_index = current_selection[0]

        if event.keysym == 'Down':
            new_index = min(current_index + 1, self.completion_listbox.size() - 1)
        elif event.keysym == 'Up':
            new_index = max(current_index - 1, 0)
        else:
            return

        self.completion_listbox.selection_clear(0, tk.END)
        self.completion_listbox.selection_set(new_index)
        self.completion_listbox.see(new_index)
        return "break"
    
    def position_completion_window(self, cursor_pos):
        """定位补全窗口位置"""
        try:
            # 获取光标在屏幕上的位置
            bbox = self.text_widget.bbox(cursor_pos)
            if bbox:
                x, y, width, height = bbox
                # 转换为屏幕坐标
                screen_x = self.text_widget.winfo_rootx() + x
                screen_y = self.text_widget.winfo_rooty() + y + height + 2

                # 确保窗口不会超出屏幕边界
                screen_width = self.completion_window.winfo_screenwidth()
                screen_height = self.completion_window.winfo_screenheight()

                # 更新窗口以获取实际大小
                self.completion_window.update_idletasks()
                window_width = self.completion_window.winfo_reqwidth()
                window_height = self.completion_window.winfo_reqheight()

                # 调整位置避免超出屏幕
                if screen_x + window_width > screen_width:
                    screen_x = screen_width - window_width - 10
                if screen_y + window_height > screen_height:
                    screen_y = self.text_widget.winfo_rooty() + y - window_height - 2

                self.completion_window.geometry(f"+{screen_x}+{screen_y}")
        except:
            # 如果定位失败，使用默认位置
            self.completion_window.geometry("+100+100")
    
    def accept_completion(self):
        """接受当前选中的补全项"""
        if not self.completion_listbox or not self.completion_candidates:
            return
    
        current_selection = self.completion_listbox.curselection()
        if not current_selection:
            return
    
        selected_index = current_selection[0]
        candidate_info = self.completion_candidates[selected_index]
    
        if len(candidate_info) == 3:
            selected_candidate, candidate_type, auto_parentheses = candidate_info
        else:
            selected_candidate, candidate_type = candidate_info
            auto_parentheses = False
    
        # 计算当前输入的结束位置
        line, col = map(int, self.completion_start_pos.split('.'))
        current_end_pos = f"{line}.{col + len(self.completion_prefix)}"
    
        # 替换文本 - 使用保存的位置而不是当前光标位置
        self.text_widget.delete(self.completion_start_pos, current_end_pos)
    
        # 定义需要自动添加空格的关键字
        keywords_need_space = {
            'import', 'from', 'return', 'yield', 'raise', 'assert', 
            'del', 'global', 'nonlocal', 'if', 'elif', 'while', 
            'for', 'try', 'except', 'finally', 'with', 'as',
            'class', 'def', 'lambda', 'and', 'or', 'not', 'in', 'is'
        }
    
        # 插入补全文本
        insert_text = selected_candidate
        
        if auto_parentheses and candidate_type in ["builtin", "method", "function"]:
            insert_text += "()"
            # 将光标放在括号之间
            self.text_widget.insert(self.completion_start_pos, insert_text)
            new_cursor_pos = f"{line}.{col + len(selected_candidate) + 1}"
            self.text_widget.mark_set(tk.INSERT, new_cursor_pos)
        elif candidate_type == "keyword" and selected_candidate in keywords_need_space:
            # 关键字后自动添加空格
            insert_text += " "
            self.text_widget.insert(self.completion_start_pos, insert_text)
            # 设置光标到空格后面
            new_cursor_pos = f"{line}.{col + len(selected_candidate) + 1}"
            self.text_widget.mark_set(tk.INSERT, new_cursor_pos)
        else:
            self.text_widget.insert(self.completion_start_pos, insert_text)
            # 设置光标到补全文本的末尾
            new_cursor_pos = f"{line}.{col + len(selected_candidate)}"
            self.text_widget.mark_set(tk.INSERT, new_cursor_pos)
    
        # 隐藏补全窗口
        self.hide_completion()
    
    def hide_completion(self, event=None):
        """隐藏补全窗口"""
        if self.completion_window:
            self.completion_window.destroy()
            self.completion_window = None
            self.completion_listbox = None
            self.completion_candidates = []
            self.completion_start_pos = None
            self.completion_prefix = ""
    
    def handle_completion_navigation(self, event):
        """处理补全窗口的导航键"""
        if not self.completion_listbox:
            return

        current_selection = self.completion_listbox.curselection()
        if not current_selection:
            self.completion_listbox.selection_set(0)
            return

        current_index = current_selection[0]

        if event.keysym == 'Down':
            new_index = min(current_index + 1, self.completion_listbox.size() - 1)
        elif event.keysym == 'Up':
            new_index = max(current_index - 1, 0)
        else:
            return

        self.completion_listbox.selection_clear(0, tk.END)
        self.completion_listbox.selection_set(new_index)
        self.completion_listbox.see(new_index)
