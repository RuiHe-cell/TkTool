#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据生成器 - 主界面
功能：提供图形化界面，简化测试数据生成操作
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import sys

# 添加父目录到路径，以便导入模块
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from gui.main_window import MainWindow


def main():
    """主函数"""
    try:
        print("启动数据生成器...")
        root = tk.Tk()
        app = MainWindow(root)
        print("界面初始化完成")
        root.mainloop()
        print("程序正常退出")
    except Exception as e:
        print(f"程序运行出错: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
